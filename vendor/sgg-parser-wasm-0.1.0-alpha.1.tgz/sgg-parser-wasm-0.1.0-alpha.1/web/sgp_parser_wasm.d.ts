/* tslint:disable */
/* eslint-disable */

/**
 * Classify a verified function name against the published risk rule table.
 */
export function classify_risk(function_name: string, verified: boolean): string;

/**
 * Decode a base64 XDR `ScVal` into a JSON string.
 */
export function decode_scval_base64(xdr_base64: string): string;

/**
 * Evaluate the published contextual risk rules against one call.
 * `call_json` is a serialized `CallUnderReview`.
 */
export function evaluate_risk_context(call_json: string, risk_context_json: string): string;

/**
 * Evaluate a tally against governor settings: `settings_json` is a
 * `GovernorSettings`, `tally_json` a `VoteCount`. Returns the
 * `VoteOutcome` as a snake_case string (`successful` / `no_quorum` /
 * `threshold_not_met`).
 */
export function evaluate_tally(tally_json: string, settings_json: string, total_supply: bigint): string;

/**
 * Parse the `contractspecv0` custom section of contract WASM bytes into a
 * JSON string describing functions, structs, enums and errors.
 */
export function parse_contract_spec(wasm_bytes: Uint8Array): string;

/**
 * Decode a Script3 proposal state into the shared `DecodedProposal` shape
 * (calls + published risk rules). `risk_context_json` is a serialized
 * `RiskContext` (`{governor, treasury_addresses, large_value_threshold}`);
 * pass `{}` for defaults (no contextual rules fire).
 */
export function script3_decode_proposal(state_json: string, risk_context_json: string): string;

/**
 * Reconstruct Script3 proposal state from a captured `get_proposal` return
 * value (base64 XDR). Offline and pure; fails closed with a JS exception.
 *
 * Returns the `Script3ProposalState` as JSON.
 */
export function script3_state_from_chain(proposal_id: number, get_proposal_xdr_base64: string): string;

/**
 * Reconstruct a Script3 tally from a captured `get_proposal_votes` return
 * value (base64 XDR). Offline and pure.
 */
export function script3_tally_from_chain(get_proposal_votes_xdr_base64: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly classify_risk: (a: number, b: number, c: number) => [number, number, number, number];
    readonly decode_scval_base64: (a: number, b: number) => [number, number, number, number];
    readonly evaluate_risk_context: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly evaluate_tally: (a: number, b: number, c: number, d: number, e: bigint, f: bigint) => [number, number, number, number];
    readonly parse_contract_spec: (a: number, b: number) => [number, number, number, number];
    readonly script3_decode_proposal: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly script3_state_from_chain: (a: number, b: number, c: number) => [number, number, number, number];
    readonly script3_tally_from_chain: (a: number, b: number) => [number, number, number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
