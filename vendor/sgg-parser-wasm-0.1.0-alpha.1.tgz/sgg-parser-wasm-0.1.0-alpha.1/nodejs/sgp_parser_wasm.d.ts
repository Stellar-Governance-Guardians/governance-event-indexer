/* tslint:disable */
/* eslint-disable */

/**
 * Classify a verified function name against the published risk rule table.
 */
export function classify_risk(function_name: string, verified: boolean): string;

/**
 * Decode a base64 XDR `ScVal` into a JSON string.
 */
export function decode_scval_base64(xdr_base64: string): string;

/**
 * Evaluate the published contextual risk rules against one call.
 * `call_json` is a serialized `CallUnderReview`.
 */
export function evaluate_risk_context(call_json: string, risk_context_json: string): string;

/**
 * Evaluate a tally against governor settings: `settings_json` is a
 * `GovernorSettings`, `tally_json` a `VoteCount`. Returns the
 * `VoteOutcome` as a snake_case string (`successful` / `no_quorum` /
 * `threshold_not_met`).
 */
export function evaluate_tally(tally_json: string, settings_json: string, total_supply: bigint): string;

/**
 * Parse the `contractspecv0` custom section of contract WASM bytes into a
 * JSON string describing functions, structs, enums and errors.
 */
export function parse_contract_spec(wasm_bytes: Uint8Array): string;

/**
 * Decode a Script3 proposal state into the shared `DecodedProposal` shape
 * (calls + published risk rules). `risk_context_json` is a serialized
 * `RiskContext` (`{governor, treasury_addresses, large_value_threshold}`);
 * pass `{}` for defaults (no contextual rules fire).
 */
export function script3_decode_proposal(state_json: string, risk_context_json: string): string;

/**
 * Reconstruct Script3 proposal state from a captured `get_proposal` return
 * value (base64 XDR). Offline and pure; fails closed with a JS exception.
 *
 * Returns the `Script3ProposalState` as JSON.
 */
export function script3_state_from_chain(proposal_id: number, get_proposal_xdr_base64: string): string;

/**
 * Reconstruct a Script3 tally from a captured `get_proposal_votes` return
 * value (base64 XDR). Offline and pure.
 */
export function script3_tally_from_chain(get_proposal_votes_xdr_base64: string): string;
