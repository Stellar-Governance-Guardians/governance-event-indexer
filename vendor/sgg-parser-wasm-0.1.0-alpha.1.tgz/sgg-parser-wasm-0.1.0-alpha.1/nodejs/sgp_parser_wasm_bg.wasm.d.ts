/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const classify_risk: (a: number, b: number, c: number) => [number, number, number, number];
export const decode_scval_base64: (a: number, b: number) => [number, number, number, number];
export const evaluate_risk_context: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const evaluate_tally: (a: number, b: number, c: number, d: number, e: bigint, f: bigint) => [number, number, number, number];
export const parse_contract_spec: (a: number, b: number) => [number, number, number, number];
export const script3_decode_proposal: (a: number, b: number, c: number, d: number) => [number, number, number, number];
export const script3_state_from_chain: (a: number, b: number, c: number) => [number, number, number, number];
export const script3_tally_from_chain: (a: number, b: number) => [number, number, number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
