/* tslint:disable */
/* eslint-disable */

/**
 * Classify a verified function name against the published risk rule table.
 */
export function classify_risk(function_name: string, verified: boolean): string;

export function decode_call(contract_id: string, function_name: string, args_json: string, spec_json?: string | null): string;

/**
 * Decode a base64 XDR `ScVal` into a JSON string.
 */
export function decode_scval_base64(xdr_base64: string): string;

/**
 * Evaluate the published contextual risk rules against one call.
 * `call_json` is a serialized `CallUnderReview`.
 */
export function evaluate_risk_context(call_json: string, risk_context_json: string): string;

/**
 * Evaluate a tally against governor settings: `settings_json` is a
 * `GovernorSettings`, `tally_json` a `VoteCount`. Returns the
 * `VoteOutcome` as a snake_case string (`successful` / `no_quorum` /
 * `threshold_not_met`).
 */
export function evaluate_tally(tally_json: string, settings_json: string, total_supply: bigint): string;

/**
 * Identify the governor adapter used by this WASM build.
 * Returns the adapter name (e.g. "script3") so downstream code can
 * reason about which governor is active.
 */
export function governor_identify(): string;

/**
 * Check whether a governance event belongs to this governor.
 *
 * This function uses the same logic as `Script3Adapter::matches_event`:
 * - The event must come from the governor contract (CA contract ID)
 * - topic[0] must be a known Script3 event symbol with matching arity
 * - If the symbol or arity doesn't match, returns `false` (never guesses),
 *   so the browser pipeline falls back to `unverified` decoding.
 *
 * Parameters:
 * - `contract_id`: the governor contract identifier
 * - `ledger`: the ledger number
 * - `topic0_b64`: base64-encoded topic[0] ScVal (the event symbol)
 * - `topic_count`: the number of topics in the event
 * - `value_b64`: base64-encoded value ScVal
 */
export function governor_matches_event(contract_id: string, ledger: number, topic0_b64: string, _topic_count: number, value_b64: string): boolean;

export function identify_governor(): string;

export function matches_event(contract_id: string, ledger: number, tx_hash: string, topics_json: string, value_b64: string): boolean;

export function normalize_event(contract_id: string, ledger: number, tx_hash: string, topics_json: string, value_b64: string): string;

/**
 * Parse the `contractspecv0` custom section of contract WASM bytes into a
 * JSON string describing functions, structs, enums and errors.
 */
export function parse_contract_spec(wasm_bytes: Uint8Array): string;

/**
 * Decode a Script3 proposal state into the shared `DecodedProposal` shape
 * (calls + published risk rules). `risk_context_json` is a serialized
 * `RiskContext` (`{governor, treasury_addresses, large_value_threshold}`);
 * pass `{}` for defaults (no contextual rules fire).
 */
export function script3_decode_proposal(state_json: string, risk_context_json: string): string;

/**
 * Reconstruct Script3 proposal state from a captured `get_proposal` return
 * value (base64 XDR). Offline and pure; fails closed with a JS exception.
 *
 * Returns the `Script3ProposalState` as JSON.
 */
export function script3_state_from_chain(proposal_id: number, get_proposal_xdr_base64: string): string;

/**
 * Reconstruct a Script3 tally from a captured `get_proposal_votes` return
 * value (base64 XDR). Offline and pure.
 */
export function script3_tally_from_chain(get_proposal_votes_xdr_base64: string): string;
